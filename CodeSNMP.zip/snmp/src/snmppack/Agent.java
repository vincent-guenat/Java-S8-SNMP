package snmppack;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Agent  implements Runnable {
		private int portA;
		InetAddress addrA;
		//private MIB mib;
		//Port par défaut (test)
	
	public void opensocketecoute() throws SocketException, UnknownHostException{	
		byte[] tampon = new byte[1000];
		
		byte[] ipAddr = new byte[]{127, 0, 0, 1};
		InetAddress addr = InetAddress.getByAddress(ipAddr);
	    // crée un socket UDP qui attends des datagrammes sur le port 20000
		DatagramSocket socket = new DatagramSocket(20000,addr);	
		// crée un objet pour stocker les données du datagramme attendu
		System.out.println("Socket ouvert sur le port :"+socket.getLocalPort()+" \n avec l'adresse : "+socket.getLocalAddress());
		DatagramPacket reception = new DatagramPacket(tampon, tampon.length);
		System.out.println("Attente de reception");
		try {
			socket.receive(reception);
			String texte =new String(tampon, 0, reception.getLength());
			System.out.println(texte);
			Thread.sleep(100);
			
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	    
		
	}

		@Override
		public void run() {
			try {
				opensocketecoute();
			} catch (SocketException | UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
	

}
