package snmppack;

public class MIB {
		String nomA;
		String addrA;
		String portA;
		String typeA;
		
		
		private MIB(String nomA, String addrA, String portA, String typeA){
			this.nomA = nomA;
			this.addrA = addrA;
			this.portA = portA;
			this.typeA = typeA;
		}
		
		
		
		
}


