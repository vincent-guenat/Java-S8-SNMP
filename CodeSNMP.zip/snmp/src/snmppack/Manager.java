package snmppack;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Properties;

public class Manager extends Agent implements Runnable {
		

	public void sendmess(InetSocketAddress addrA, Message mess) throws SocketException, UnknownHostException{
		byte[] tampon = new byte[1000];
		
	    // crée un socket UDP qui attends des datagrammes sur le port 20001
		DatagramSocket socket = new DatagramSocket(20001);	
		// crée un objet pour envoyer les données du datagramme 
		System.out.println("Socket ouvert sur le port :"+socket.getLocalPort()+" \n avec l'adresse : "+socket.getLocalAddress());
		DatagramPacket envoi=new DatagramPacket(tampon, tampon.length, addrA);
		System.out.println("emission");	
		try {
			socket.send(envoi);
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	public void run() {
		try {
			byte[] ipaddr = new byte[]{127, 0, 0, 1};
			Inet4Address addr = (Inet4Address) InetAddress.getByAddress(ipaddr);
					
			InetSocketAddress addrA = new InetSocketAddress(addr, 20000);
			Message mess = new Message("Bonjour");
			
			sendmess(addrA, mess);
			
		} catch (SocketException | UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
