package snmppack;

import java.net.SocketException;


public class ThreadPrinc {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Interface inter = new Interface();
		//inter.choixInit();
		//Message mess = new Message("bonjour");
		Agent agent = new Agent();
		Thread th1 = new Thread(agent); 	
		th1.start(); 
		
		//Agent agent2 = new Agent();	
		//Thread th2 = new Thread(agent2);
		//th2.start();
		/*try {
			th1.wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		Manager man = new Manager();
		Thread th2 = new Thread(man);
		th2.start();
		//th1.notifyAll();
		
	}

}
