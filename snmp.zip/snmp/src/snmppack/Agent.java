package snmppack;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Agent extends Equipement implements Runnable {
		
	/**
	 * Constructeur de l'agent avec une adresse IP en InetAddress.
	 * @param addrA Adresse IP de l'agent a construire.
	 */
	public Agent(InetAddress addrA) {
		super(addrA,60000);
	}
	
	/**
	 * Constructeur de l'agent avec une adresse IP en String.
	 * @param addrA Adresse IP de l'agent a construire.
	 * @throws UnknownHostException
	 */
	public Agent(String addrA) throws UnknownHostException {
		super(InetAddress.getByName(addrA),60000);
	}
	

	@Override
	public void run() {
		// 2 threads : un pour monitor, un pour recevoir / r�pondre.
	}
	
	
	public static void main(String[] args) {
		InetAddress adr = null;
		Agent agent = null;
		Manager man=null;
		try {
			adr = InetAddress.getLocalHost();
			agent = new Agent(adr);
			Thread th1 = new Thread(agent); 	
			th1.start();
			man = new Manager(adr);
			Thread th2 = new Thread(man);
			th2.start();
		} catch (UnknownHostException e) {
			System.err.println("Erreur de creation du manager ou de l'agent : " + e);
		}
		
	}
	
	

}
