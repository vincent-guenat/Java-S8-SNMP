package snmppack;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 * Classe abstraite dont herite les Agents et Managers.
 */
public class Equipement {
	protected InetAddress addr;
	protected int port;
	protected DatagramSocket sock;
	
	/**
	 * Constructeur � partir d'une adresse ip de type InetAddress et d'un port integer.
	 * @param addr L'adresse de l'hote sur laquelle mettre l'agent.
	 * @param port Le numero du port pour placer le socket.
	 */
	public Equipement(InetAddress addr, int port) {
		this.addr = addr;
		this.port = port;
		this.sock = initSock();
	}
	
	/**
	 * Afficher un message d'erreur sur la chaine d'erreur Syster.err.
	 * @param msg Le contenu du message d'erreur.
	 */
	protected void errorMessage (String msg) {
		System.err.println("Erreur sur " + this + " :\n" + msg);
	}
	
	/**
	 * Initialisation du socket UDP.
	 * @return Le socket cree.
	 */
	private DatagramSocket initSock() {
		try {
			sock = new DatagramSocket(port,addr);
			System.out.println("Socket cree pour " + this);
		}
		catch (SocketException e) {
			errorMessage("Erreur de creation du socket : " + e);
			Thread.currentThread().interrupt();
		}
		return sock;
	}
	
	/**
	 * Envoyer un message a un equipement
	 * @param destAddr Adresse IP de destination.
	 * @param destPort Port de destination.
	 * @param data Contenu du paquet a transmettre.
	 * @return Renvoi 0 si l'envoi a fonctionne ou un entier positif sinon.
	 */
	protected int sendMsg(InetAddress destAddr, int destPort, String data) {
		try {
			byte[] dataBytes = data.getBytes();
			DatagramPacket dgram = new DatagramPacket(dataBytes, dataBytes.length);
			sock.send(dgram);
			return 0;
		} catch (IOException e) {
			System.err.println("Erreur d'envoi de datagramme depuis " + this + " : " + e);
			return 1;
		}
	}
	
	/**
	 * Recoit un datagramme UPD.
	 * @return Le contenu du datagramme, au format Message.
	 */
	protected Message rcvMsg() {
		try {
			byte[] buffer = new byte[255];
			DatagramPacket dgram = new DatagramPacket(buffer,buffer.length);
			sock.receive(dgram);
			return new Message(dgram.getData().toString());
		} catch (IOException e) {
			System.err.println("Erreur de reception de datagramme : " + e);
			return null;
		}
	}
	
}
