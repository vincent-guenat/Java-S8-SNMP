package snmppack;

public class MIB {
		private String nomA;
		private String addrA;
		private String portA;
		private String typeA;
		
		/**
		 * Constructeur de la MIB d'un agent.
		 * @param nomA Le nom de l'agent.
		 * @param addrA L'adresse IP de l'agent.
		 * @param portA Le port de l'agent.
		 * @param typeA Le type d'equipement (ordinateur, routeur, switch).
		 */
		private MIB(String nomA, String addrA, String portA, String typeA){
			this.nomA = nomA;
			this.addrA = addrA;
			this.portA = portA;
			this.typeA = typeA;
		}


		public String getNomA() {
			return nomA;
		}


		public void setNomA(String nomA) {
			this.nomA = nomA;
		}


		public String getAddrA() {
			return addrA;
		}


		public void setAddrA(String addrA) {
			this.addrA = addrA;
		}


		public String getPortA() {
			return portA;
		}


		public void setPortA(String portA) {
			this.portA = portA;
		}


		public String getTypeA() {
			return typeA;
		}


		public void setTypeA(String typeA) {
			this.typeA = typeA;
		}
		
}


