package snmppack;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

public class Manager extends Equipement implements Runnable {
	
	private Properties config;
	
	/**
	 * Constructeur du Manager a partir d'une InetAdress.
	 * @param addr L'adresse IP du manager.
	 */
	public Manager(InetAddress addr) {
		super(addr,60010);
	}
	
	/**
	 * Constructeur du Manager a partir d'une chaine de caracteres.
	 * @param addr
	 * @throws UnknownHostException
	 */
	public Manager(String addr) throws UnknownHostException {
		super(InetAddress.getByName(addr),60010);
	}
	
	/**
	 * Ajouter un agent au fichier de configuration du manager
	 * @param idA Identifiant de l'agent.
	 * @param coordA Coordonnees (adresse IP + port).
	 * @return La precedente valeur pour cette cle ou null s'il n'y en avait
	 * pas.
	 */
	public String addAgent(String idA, String coordA) {
		return (String) config.setProperty(idA, coordA);
	}
	
	/**
	 * Retirer un agent du fichier de configuration du manager
	 * @param idA Identifiant de l'agent.
	 * @return La precedente valeur pour la cle supprimee ou null s'il n'y en
	 * avait pas.
	 */
	public String delAgent(String idA) {
		return (String) config.remove(idA);
	}
	
	/**
	 * Obtenir l'adresse IP d'un agent depuis le fichier de configuration du manager
	 * @param idA L'identifiant de l'agent.
	 * @return L'adresse IP de l'agent correspondant a cet ID.
	 */
	public String getAddrA(String idA) {
		return  config.getProperty(idA);
	}
	
	
	public void getRequest() {
		
	}
	
	
	public void setRequest() {
		
	}
	
	@Override
	public void run() {
		int valChoix = -1;
		// Chercher a recup la config
		
		// Debut boucle
		while (valChoix != 0) {
			// afficher menu princ
			
			// case de l'ordre de l'utilisateur
			switch (valChoix) {
			case 0: // quitter apres sauvegarde de config
//				config.storeToXML(os,null);
				break;
			case 1: // addAgent
				// invoquer le menu d'ajout
				break;
			case 2: // delAgent
				// invoquer le menu de suppression
				break;
			case 3: // getRequest
				// invoquer getRequest
				break;
			case 4: // setRequest
				// invoquer setRequest
				break;
			default: // si rien, rien
				// afficher message d'erreur
				break;
			}
		}
		
	}
	
}
