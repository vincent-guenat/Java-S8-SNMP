package snmppack;

public class Message {
	private String type;
	private String id;
	private String codeRetour;
	private String contenu;

	/**
	 * Constructeur d'un message a partir d'une chaine a couper.
	 * @param data
	 */
	public Message(String data) {
		System.out.println(data);
		String text[] = data.split(" ");
		this.type = text[0];
		this.id = text[1];
		this.codeRetour = text[2];
		this.contenu = text[3];
	}
	
	/**
	 * COnstructeur d'un message a partir de plusieurs champs
	 * @param type
	 * @param id
	 * @param codeRetour
	 * @param contenu
	 */
	public Message(String type, String id, String codeRetour, String contenu) {
		this.type = type;
		this.id = id;
		this.codeRetour = codeRetour;
		this.contenu = contenu;
	}
}
